import face_recognition
import cv2
import os
import numpy as np
import tkinter as tk
from tkinter import filedialog
from threading import Thread
import platform
import threading
import time

MARKED_FACES_FILE = "marked_faces.txt"
ALERT_COOLDOWN = 2

if not os.path.exists("faces"):
    os.makedirs("faces")

marked_faces_encodings = []
marked_faces_paths = []
detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
last_alert_time = 0
camera_thread = None
captured_face_count = 0

def play_alert_sound():
    if platform.system() == 'Windows':
        import winsound
        winsound.Beep(1000, 500)
    elif platform.system() == 'Darwin':
        os.system('osascript -e "beep"')
    else:
        os.system('aplay /usr/share/sounds/alsa/Front_Center.wav')

def play_alert_in_thread():
    sound_thread = threading.Thread(target=play_alert_sound)
    sound_thread.start()

def save_new_face(face_image):
    global captured_face_count
    captured_face_count += 1
    face_filename = f"faces/image{captured_face_count}.jpg"
    cv2.imwrite(face_filename, face_image)
    print(f"New face saved: {face_filename}")

def face_recognition_thread():
    global last_alert_time, captured_face_count
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Can't open webcam")
        return

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        equalized_frame = cv2.equalizeHist(gray_frame)
        rgb_frame = cv2.cvtColor(equalized_frame, cv2.COLOR_GRAY2RGB)

        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            cv2.rectangle(frame, (left, top), (right, bottom), (255, 0, 0), 2)

            match_results = face_recognition.compare_faces(marked_faces_encodings, face_encoding, tolerance=0.5)

            if any(match_results) and (time.time() - last_alert_time > ALERT_COOLDOWN):
                play_alert_in_thread()
                last_alert_time = time.time()
                print("Thief detected!")

            if not any(match_results):
                new_face_image = frame[top:bottom, left:right]
                save_new_face(new_face_image)

        cv2.imshow('Face Recognition', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


def mark_face():
    selected_file = filedialog.askopenfilename(initialdir="faces", title="Select Face",
                                               filetypes=(("JPEG files", "*.jpg"), ("All files", "*.*")))
    if selected_file:
        marked_faces_paths.append(selected_file)
        print(f"Marked face: {selected_file}")
        save_marked_faces()
        load_marked_faces()

def save_marked_faces():
    with open(MARKED_FACES_FILE, "w") as f:
        for face_path in marked_faces_paths:
            f.write(f"{face_path}\n")

def close_program():
    stop_face_recognition()
    root.destroy()

def load_marked_faces():
    global marked_faces_encodings, marked_faces_paths
    if os.path.exists(MARKED_FACES_FILE):
        with open(MARKED_FACES_FILE, "r") as f:
            marked_faces_paths = [line.strip() for line in f.readlines()]

        marked_faces_encodings = []
        for face_path in marked_faces_paths:
            face_image = face_recognition.load_image_file(face_path)
            face_encodings = face_recognition.face_encodings(face_image)
            if face_encodings:
                marked_faces_encodings.append(face_encodings[0])
        print(f"Loaded marked faces: {marked_faces_paths}")

    global captured_face_count
    existing_faces = len(os.listdir("faces"))
    captured_face_count = existing_faces

def start_face_recognition():
    global camera_thread

    if camera_thread and camera_thread.is_alive():
        stop_face_recognition()

    camera_thread = Thread(target=face_recognition_thread)
    camera_thread.start()

def stop_face_recognition():
    global camera_thread
    if camera_thread and camera_thread.is_alive():
        cv2.destroyAllWindows()
        camera_thread.join()

root = tk.Tk()
root.title("Face detection alarm system")
window_width = 350
window_height = 350

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width // 2) - (window_width // 2)
y = (screen_height // 2) - (window_height // 2)
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

load_marked_faces()

recognize_button = tk.Button(root, text="Detecting faces", command=start_face_recognition, width=20, height=3)
recognize_button.pack(pady=20)

mark_button = tk.Button(root, text="Mark Target", command=mark_face, width=20, height=3)
mark_button.pack(pady=20)

close_button = tk.Button(root, text="Close", command=close_program, width=20, height=3)
close_button.pack(pady=20)

def on_closing():
    stop_face_recognition()
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()
